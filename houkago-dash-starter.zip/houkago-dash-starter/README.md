# 放課後ダッシュ！

保育園から中学校までの同級生6人で遊ぶ、協力と妨害が混ざる横スクロールアクションゲーム。

## 現在の状態
- 1人用操作確認版のコード
- Cloudflare Durable Objectsによる6人ルームサーバーの雛形
- 開発タスクとアーキテクチャ判断

## ローカル起動
```bash
npm install
npm run dev:web
```

リアルタイムサーバー:
```bash
npm run dev:server
```

## 配信方針
- フロント: Cloudflare Pages推奨（Vercelでも可）
- サーバー: Cloudflare Workers + Durable Objects

Cloudflareアカウントを接続後:
```bash
npm run deploy:server
```

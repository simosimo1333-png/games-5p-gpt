# Architecture Decision: 放課後ダッシュ！

## 採用構成
- クライアント: Phaser + Vite + TypeScript
- 静的配信: Cloudflare Pages（開発中はVercelでも可）
- リアルタイム: Cloudflare Workers + Durable Objects + WebSocket
- ルーム単位: 1ルームコード = 1 Durable Object

## 理由
1. 6人の状態を1つのルームで直列に処理できる。
2. WebSocket接続・切断・再接続をルーム単位で管理しやすい。
3. フロントとゲームサーバーを分離し、操作感の開発と通信開発を独立させられる。
4. 将来、権威サーバー方式（サーバーが正しい位置を決定）へ段階的に移行できる。

## 開発段階
- Phase 1: 1人用操作確認版
- Phase 2: 1コース完成
- Phase 3: つかむ・押す
- Phase 4: 6人同期
- Phase 5: 協力ギミック
- Phase 6: アイテム・得点

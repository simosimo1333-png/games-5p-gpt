import { DurableObject } from "cloudflare:workers";

interface Env { ROOMS: DurableObjectNamespace<GameRoom>; }
interface PlayerState { id: string; name: string; x: number; y: number; vx: number; vy: number; seq: number; }

type ClientMessage =
  | { type: "join"; playerId: string; name: string }
  | { type: "input"; playerId: string; seq: number; left: boolean; right: boolean; jump: boolean }
  | { type: "ping"; sentAt: number };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === "/health") return Response.json({ ok: true });
    const match = url.pathname.match(/^\/room\/([A-Z0-9]{4,8})$/i);
    if (!match) return new Response("Not found", { status: 404 });
    const roomCode = match[1].toUpperCase();
    return env.ROOMS.getByName(roomCode).fetch(request);
  },
};

export class GameRoom extends DurableObject<Env> {
  private players = new Map<string, PlayerState>();

  async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return Response.json({ players: [...this.players.values()] });
    }
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ playerId: null });
    server.send(JSON.stringify({ type: "snapshot", players: [...this.players.values()] }));
    return new Response(null, { status: 101, webSocket: client });
  }

  async webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer) {
    const text = typeof raw === "string" ? raw : new TextDecoder().decode(raw);
    const message = JSON.parse(text) as ClientMessage;
    if (message.type === "join") {
      if (this.players.size >= 6 && !this.players.has(message.playerId)) {
        ws.send(JSON.stringify({ type: "error", code: "ROOM_FULL" }));
        ws.close(1008, "Room full");
        return;
      }
      this.players.set(message.playerId, { id: message.playerId, name: message.name, x: 150, y: 500, vx: 0, vy: 0, seq: 0 });
      ws.serializeAttachment({ playerId: message.playerId });
      this.broadcast({ type: "playerJoined", player: this.players.get(message.playerId) });
      return;
    }
    if (message.type === "input") {
      const player = this.players.get(message.playerId);
      if (!player || message.seq <= player.seq) return;
      player.seq = message.seq;
      player.vx = message.left === message.right ? 0 : message.left ? -285 : 285;
      if (message.jump) player.vy = -540;
      this.broadcast({ type: "inputAck", playerId: player.id, seq: player.seq, vx: player.vx, vy: player.vy });
      return;
    }
    if (message.type === "ping") ws.send(JSON.stringify({ type: "pong", sentAt: message.sentAt }));
  }

  async webSocketClose(ws: WebSocket) {
    const attachment = ws.deserializeAttachment() as { playerId: string | null } | null;
    if (attachment?.playerId) {
      this.players.delete(attachment.playerId);
      this.broadcast({ type: "playerLeft", playerId: attachment.playerId });
    }
  }

  private broadcast(message: unknown) {
    const payload = JSON.stringify(message);
    for (const socket of this.ctx.getWebSockets()) {
      try { socket.send(payload); } catch { /* closed socket */ }
    }
  }
}

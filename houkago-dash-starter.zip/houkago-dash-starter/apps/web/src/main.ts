import Phaser from "phaser";
import "./style.css";

const WIDTH = 1280;
const HEIGHT = 720;

class BootScene extends Phaser.Scene {
  private player!: Phaser.Physics.Arcade.Sprite;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private left = false;
  private right = false;
  private jumpQueued = false;
  private timerText!: Phaser.GameObjects.Text;
  private startedAt = 0;

  constructor() {
    super("boot");
  }

  create() {
    this.cameras.main.setBackgroundColor("#a7d8ff");
    this.physics.world.setBounds(0, 0, 3200, HEIGHT);

    this.add.rectangle(1600, 650, 3200, 140, 0x84a85c).setDepth(-3);
    this.add.rectangle(1600, 590, 3200, 20, 0xb8c48c).setDepth(-2);

    const platforms = this.physics.add.staticGroup();
    this.makePlatform(platforms, 480, 530, 240, 32, 0xd9b38c);
    this.makePlatform(platforms, 820, 450, 180, 32, 0xd9b38c);
    this.makePlatform(platforms, 1180, 380, 220, 32, 0xd9b38c);
    this.makePlatform(platforms, 1570, 500, 320, 32, 0x64748b);
    this.makePlatform(platforms, 2050, 420, 260, 32, 0x64748b);
    this.makePlatform(platforms, 2500, 340, 260, 32, 0xf59e0b);

    this.add.text(120, 115, "放課後ダッシュ！", {
      fontFamily: "system-ui, sans-serif",
      fontSize: "56px",
      fontStyle: "bold",
      color: "#0f172a",
      stroke: "#ffffff",
      strokeThickness: 8,
    }).setScrollFactor(0);

    this.add.text(124, 184, "操作確認版：校門まで走れ！", {
      fontFamily: "system-ui, sans-serif",
      fontSize: "25px",
      color: "#334155",
      backgroundColor: "#ffffffcc",
      padding: { x: 12, y: 7 },
    }).setScrollFactor(0);

    this.timerText = this.add.text(1050, 40, "0.0秒", {
      fontFamily: "monospace",
      fontSize: "30px",
      fontStyle: "bold",
      color: "#ffffff",
      backgroundColor: "#0f172acc",
      padding: { x: 18, y: 10 },
    }).setScrollFactor(0).setDepth(20);

    this.player = this.physics.add.sprite(150, 500, "");
    this.player.setDisplaySize(56, 76).setTint(0xef4444);
    this.player.setCollideWorldBounds(true);
    this.player.setBounce(0.02);
    this.player.body!.setSize(48, 70);
    this.physics.add.collider(this.player, platforms);

    const finish = this.add.rectangle(2850, 470, 24, 240, 0xfacc15);
    this.physics.add.existing(finish, true);
    this.add.text(2780, 310, "校門\nGOAL", {
      align: "center",
      fontFamily: "system-ui",
      fontSize: "30px",
      fontStyle: "bold",
      color: "#7c2d12",
    });
    this.physics.add.overlap(this.player, finish, () => this.finish());

    this.cameras.main.startFollow(this.player, true, 0.08, 0.08, -240, 80);
    this.cameras.main.setBounds(0, 0, 3200, HEIGHT);
    this.cursors = this.input.keyboard!.createCursorKeys();
    this.bindTouchControls();
    this.startedAt = performance.now();
  }

  private makePlatform(group: Phaser.Physics.Arcade.StaticGroup, x: number, y: number, w: number, h: number, color: number) {
    const platform = this.add.rectangle(x, y, w, h, color);
    this.physics.add.existing(platform, true);
    group.add(platform);
  }

  private bindTouchControls() {
    const addButton = (x: number, label: string, onDown: () => void, onUp: () => void) => {
      const circle = this.add.circle(x, 630, 58, 0x0f172a, 0.72).setScrollFactor(0).setDepth(30).setInteractive();
      this.add.text(x, 630, label, { fontSize: "34px", color: "#fff", fontStyle: "bold" }).setOrigin(0.5).setScrollFactor(0).setDepth(31);
      circle.on("pointerdown", onDown);
      circle.on("pointerup", onUp);
      circle.on("pointerout", onUp);
    };
    addButton(92, "◀", () => this.left = true, () => this.left = false);
    addButton(226, "▶", () => this.right = true, () => this.right = false);
    addButton(1160, "JUMP", () => this.jumpQueued = true, () => {});
  }

  update() {
    const speed = 285;
    const moveLeft = this.cursors.left.isDown || this.left;
    const moveRight = this.cursors.right.isDown || this.right;
    if (moveLeft === moveRight) this.player.setVelocityX(0);
    else this.player.setVelocityX(moveLeft ? -speed : speed);

    const grounded = this.player.body!.blocked.down || this.player.body!.touching.down;
    if ((Phaser.Input.Keyboard.JustDown(this.cursors.up) || Phaser.Input.Keyboard.JustDown(this.cursors.space) || this.jumpQueued) && grounded) {
      this.player.setVelocityY(-540);
    }
    this.jumpQueued = false;

    if (this.player.y > 690) {
      this.player.setPosition(Math.max(120, this.player.x - 220), 470);
      this.player.setVelocity(0, 0);
    }

    const elapsed = (performance.now() - this.startedAt) / 1000;
    this.timerText.setText(`${elapsed.toFixed(1)}秒`);
  }

  private finish() {
    this.physics.pause();
    const elapsed = (performance.now() - this.startedAt) / 1000;
    this.add.rectangle(WIDTH / 2, HEIGHT / 2, 720, 260, 0x0f172a, 0.94).setScrollFactor(0).setDepth(100);
    this.add.text(WIDTH / 2, HEIGHT / 2 - 55, "校門に到着！", {
      fontFamily: "system-ui",
      fontSize: "54px",
      fontStyle: "bold",
      color: "#facc15",
    }).setOrigin(0.5).setScrollFactor(0).setDepth(101);
    this.add.text(WIDTH / 2, HEIGHT / 2 + 40, `タイム ${elapsed.toFixed(1)}秒`, {
      fontFamily: "system-ui",
      fontSize: "34px",
      color: "#ffffff",
    }).setOrigin(0.5).setScrollFactor(0).setDepth(101);
  }
}

new Phaser.Game({
  type: Phaser.AUTO,
  parent: "game",
  width: WIDTH,
  height: HEIGHT,
  backgroundColor: "#a7d8ff",
  physics: {
    default: "arcade",
    arcade: { gravity: { x: 0, y: 1150 }, debug: false },
  },
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  scene: [BootScene],
});

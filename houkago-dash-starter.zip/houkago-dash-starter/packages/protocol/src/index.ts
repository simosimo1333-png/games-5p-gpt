export const MAX_PLAYERS = 6;
export type RoomCode = string;
export type PlayerId = string;
export interface Vec2 { x: number; y: number; }
